from modules.layers.encoders import *
from modules.layers.decoders import *


released_models = {
    "BertBiLSTMNCRF": {
        "encoder": BertBiLSTMEncoder,
        "decoder": NCRFDecoder
    }
}
